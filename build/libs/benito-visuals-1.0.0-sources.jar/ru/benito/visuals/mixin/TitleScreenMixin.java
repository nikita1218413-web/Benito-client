package ru.benito.visuals.mixin;

import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.benito.visuals.gui.UpdateMainMenu;

/**
 * Патч главного меню: добавляет кнопки "Зайти на FunTime" и "Настройки Benito"
 * и рисует брендинг Benito.
 */
@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 implements UpdateMainMenu.ScreenAccess {

    protected TitleScreenMixin() { super(null); }

    @Inject(method = "init", at = @At("TAIL"))
    private void benito$init(CallbackInfo ci) {
        UpdateMainMenu.inject((class_442) (Object) this);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void benito$renderBrand(class_332 ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        UpdateMainMenu.renderBrand(ctx, this.field_22789, this.field_22790);
    }

    @Override
    public void benito$addDrawable(class_339 widget) {
        this.method_37063(widget);
    }
}
