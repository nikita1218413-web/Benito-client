package ru.benito.visuals.mixin;

import net.minecraft.class_4587;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.benito.visuals.BenitoClient;
import ru.benito.visuals.module.impl.visuals.ViewModel;

/**
 * ViewModel — сдвигает руки по X/Y/Z перед рендером предмета в руке.
 */
@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {

    @Inject(method = "renderFirstPersonItem",
            at = @At("HEAD"))
    private void benito$applyOffset(net.minecraft.class_742 player,
                                    float tickDelta,
                                    float pitch,
                                    net.minecraft.class_1268 hand,
                                    float swingProgress,
                                    net.minecraft.class_1799 item,
                                    float equipProgress,
                                    class_4587 matrices,
                                    net.minecraft.class_4597 vertexConsumers,
                                    int light,
                                    CallbackInfo ci) {
        if (BenitoClient.get() == null) return;
        ViewModel vm = BenitoClient.get().modules().get(ViewModel.class);
        if (vm == null || !vm.isEnabled()) return;
        matrices.method_46416(vm.getX(), vm.getY(), vm.getZ());
    }
}
