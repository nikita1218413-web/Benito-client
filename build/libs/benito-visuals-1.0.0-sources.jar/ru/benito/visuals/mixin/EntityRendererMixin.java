package ru.benito.visuals.mixin;

import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.benito.visuals.BenitoClient;
import ru.benito.visuals.module.impl.combat.CustomHitBox;

/**
 * CustomHitBox — рисует дополнительный визуальный хитбокс, увеличенный по осям.
 * Используем хук @Inject в EntityRenderer#render(EntityRenderState, MatrixStack, VertexConsumerProvider, int).
 * В 1.21.4 render теперь использует EntityRenderState, а AABB берём из entity напрямую
 * через {@link class_10017#hitbox} (нет), поэтому оставляем подход "expand" на клиентской стороне
 * через модификацию Entity#getBoundingBox.
 */
@Mixin(class_897.class)
public abstract class EntityRendererMixin {

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/EntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"))
    private void benito$hitboxMarker(class_10017 state,
                                     class_4587 matrices,
                                     class_4597 vcp,
                                     int light,
                                     CallbackInfo ci) {
        // Реальная логика раздувания — в Entity#getVisibilityBoundingBox Mixin (не включён здесь
        // для простоты), либо хранением множителя в BenitoClient для внешней отрисовки wireframe.
        if (BenitoClient.get() == null) return;
        CustomHitBox mod = BenitoClient.get().modules().get(CustomHitBox.class);
        if (mod == null || !mod.isEnabled()) return;

        // Маркер: модуль активен. Реальное увеличение AABB — через отдельный Mixin на Entity
        // (см. комментарий выше; оставлено как точка расширения).
    }

    /** Утилита для внешних рендереров: раздувает bounding box на {@code expand} по каждой оси. */
    public static class_238 expand(class_1297 entity, float expand) {
        class_238 b = entity.method_5829();
        return b.method_1009(expand, expand, expand);
    }
}
