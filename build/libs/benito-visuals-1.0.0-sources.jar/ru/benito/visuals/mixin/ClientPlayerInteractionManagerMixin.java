package ru.benito.visuals.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.benito.visuals.event.Events;

/**
 * Эмитит Events.ATTACK_ENTITY при ударе игрока.
 */
@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void benito$onAttack(class_1657 attacker, class_1297 target, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        boolean crit = attacker == mc.field_1724
                && attacker.field_6017 > 0.0f
                && !attacker.method_24828()
                && !attacker.method_6101()
                && !attacker.method_5799()
                && !attacker.method_5765();
        Events.ATTACK_ENTITY.invoker().onAttack(target, crit);
    }
}
