package ru.benito.visuals.gui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;
import ru.benito.visuals.render.RenderUtils;

/**
 * UpdateMainMenu — кастомное главное меню.
 *
 * Добавляет в стандартный TitleScreen две кастомные кнопки:
 *   1) "Зайти на FunTime"  — прямой коннект на play.funtime.su
 *   2) "Настройки Benito"  — открывает PanelGuiBeta (ClickGUI)
 *
 * Подключение — через TitleScreenMixin (см. mixin/).
 */
public final class UpdateMainMenu {

    public static final String FUNTIME_ADDRESS = "play.funtime.su";

    private UpdateMainMenu() {}

    /** Вызывается из TitleScreenMixin на init(). */
    public static void inject(class_442 screen) {
        int centerX = screen.field_22789 / 2;
        int y = screen.field_22790 / 4 + 120;

        class_4185 join = class_4185
                .method_46430(class_2561.method_43471("benito.menu.join"), b -> joinFuntime(screen))
                .method_46434(centerX - 100, y, 200, 20)
                .method_46431();

        class_4185 settings = class_4185
                .method_46430(class_2561.method_43471("benito.menu.settings"),
                        b -> class_310.method_1551().method_1507(new PanelGuiBeta()))
                .method_46434(centerX - 100, y + 24, 200, 20)
                .method_46431();

        addWidget(screen, join);
        addWidget(screen, settings);
    }

    /** Рисует лого Benito поверх стандартного TitleScreen. */
    public static void renderBrand(class_332 ctx, int screenW, int screenH) {
        int x = 10;
        int y = screenH - 28;
        String s = "§lBenito Visuals §r§7v1.0 §8· §f" + UpdateMainMenu.FUNTIME_ADDRESS;
        RenderUtils.text(ctx, s, x, y, 0xFFFFFFFF, true);
    }

    private static void joinFuntime(class_437 parent) {
        class_310 mc = class_310.method_1551();
        class_642 info = new class_642("FunTime", FUNTIME_ADDRESS, class_642.class_8678.field_45611);
        net.minecraft.class_412.method_36877(
                parent, mc, class_639.method_2950(FUNTIME_ADDRESS), info, false, null);
    }

    /** Добавить виджет в экран через публичное API addDrawableChild. */
    private static void addWidget(class_442 screen, class_4185 w) {
        ((ScreenAccess) screen).benito$addDrawable(w);
    }

    /** Контракт, который реализуется через TitleScreenMixin (invoker accessor). */
    public interface ScreenAccess {
        void benito$addDrawable(net.minecraft.class_339 widget);
    }
}
