package ru.benito.visuals.module.impl.funtime;

import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;

/**
 * CoordInvite — отправка своих координат в чат командой.
 * По умолчанию биндится на Y (см. {@link ru.benito.visuals.input.Keybindings}).
 */
public final class CoordInvite extends Module {

    /** Команда для отправки; "%s" для X/Y/Z вставляются в порядке. */
    private String template = "/msg %target% Мои координаты: %x% %y% %z%";
    private String target   = "";

    public CoordInvite() {
        super("CoordInvite", "CoordInvite",
                "Отправка координат другу", Category.FUNTIME);
    }

    public void sendCoords() {
        class_310 mc = class_310.method_1551();
        class_746 p = mc.field_1724;
        if (p == null || mc.method_1562() == null) return;

        class_2338 pos = p.method_24515();
        String msg;
        if (target.isBlank()) {
            msg = "Мои координаты: " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260();
        } else {
            msg = template
                    .replace("%target%", target)
                    .replace("%x%", String.valueOf(pos.method_10263()))
                    .replace("%y%", String.valueOf(pos.method_10264()))
                    .replace("%z%", String.valueOf(pos.method_10260()));
        }

        if (msg.startsWith("/")) {
            mc.method_1562().method_45730(msg.substring(1));
        } else {
            mc.method_1562().method_45729(msg);
        }
    }

    public String getTarget() { return target; }
    public void   setTarget(String t) { this.target = t == null ? "" : t; }
    public String getTemplate() { return template; }
    public void   setTemplate(String t) { this.template = t; }
}
