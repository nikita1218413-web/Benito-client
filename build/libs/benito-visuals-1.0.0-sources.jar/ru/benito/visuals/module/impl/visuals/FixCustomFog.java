package ru.benito.visuals.module.impl.visuals;

import net.minecraft.class_310;
import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;

/**
 * FixCustomFog — снижает эффект кастомного тумана, выставляя клиентский
 * render-distance на максимум пока модуль включён (альтернатива Mixin'у,
 * т.к. BackgroundRenderer.FogData в 1.21.4 имеет package-private доступ).
 */
public final class FixCustomFog extends Module {

    private int savedDistance = -1;

    public FixCustomFog() {
        super("FixCustomFog", "FixCustomFog",
                "Убирает кастомный туман", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        class_310 mc = class_310.method_1551();
        savedDistance = mc.field_1690.method_42503().method_41753();
        mc.field_1690.method_42503().method_41748(32);
    }

    @Override
    protected void onDisable() {
        if (savedDistance > 0) {
            class_310.method_1551().field_1690.method_42503().method_41748(savedDistance);
        }
    }
}
