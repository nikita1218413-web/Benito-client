package ru.benito.visuals.module.impl.funtime;

import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;
import ru.benito.visuals.render.RenderUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_476;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * AhHelper — помощник для аукциона FunTime.
 *
 * Алгоритм:
 *  - При открытом AH-контейнере (GenericContainerScreen) обходим все слоты.
 *  - Читаем имя и LORE-компонент предмета.
 *  - Ищем число после слов "Цена"/"Price" — это стоимость лота.
 *  - Считаем цену за штуку = price / stack.count.
 *  - Если "per-unit" цена лота ниже среднего по окну на 30%+ — помечаем "выгодой"
 *    и показываем в HUD-плашке 10 секунд.
 */
public final class AhHelper extends Module {

    private static final Pattern PRICE = Pattern.compile("(\\d[\\d\\s.,']*)");

    private String lastDeal = "";
    private long lastDealTime = 0;

    public AhHelper() {
        super("AhHelper", "AhHelper",
                "Помощник аукциона", Category.FUNTIME);
    }

    @Override
    public void onTick() {
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof class_476 screen)) return;
        analyze(screen);
    }

    private void analyze(class_465<?> screen) {
        long best = Long.MAX_VALUE;
        String bestName = null;
        long total = 0;
        int count = 0;

        for (class_1735 slot : screen.method_17577().field_7761) {
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            Long price = extractPrice(stack.method_7964());
            if (price == null) price = extractFromLore(stack);
            if (price == null || price <= 0) continue;

            long perUnit = price / Math.max(1, stack.method_7947());
            total += perUnit;
            count++;
            if (perUnit < best) {
                best = perUnit;
                bestName = stack.method_7964().getString();
            }
        }

        if (count == 0 || bestName == null) return;
        long avg = total / count;
        if (best < avg * 0.7) {
            lastDeal = bestName + " — " + best + " (средн: " + avg + ")";
            lastDealTime = System.currentTimeMillis();
        }
    }

    private Long extractFromLore(class_1799 stack) {
        class_9290 lore = stack.method_57824(class_9334.field_49632);
        if (lore == null) return null;
        for (class_2561 line : lore.comp_2400()) {
            Long p = extractPrice(line);
            if (p != null) return p;
        }
        return null;
    }

    private Long extractPrice(class_2561 text) {
        if (text == null) return null;
        String s = text.getString().toLowerCase();
        if (s.contains("цена") || s.contains("price") || s.contains("стоимость")) {
            Matcher m = PRICE.matcher(s);
            if (m.find()) {
                String digits = m.group(1).replaceAll("[\\s.,']", "");
                try { return Long.parseLong(digits); } catch (Exception ignored) {}
            }
        }
        return null;
    }

    @Override
    public void onHudRender(class_332 ctx, float tickDelta) {
        if (lastDeal.isEmpty() || System.currentTimeMillis() - lastDealTime > 10_000) return;
        int x = 6, y = 6;
        int w = RenderUtils.textWidth("AH: " + lastDeal) + 8;
        RenderUtils.rect(ctx, x, y, w, 14, 0xC0000000, 0xFF6B4CFF);
        RenderUtils.text(ctx, "§eAH: §f" + lastDeal, x + 4, y + 3, 0xFFFFFFFF, true);
    }
}
