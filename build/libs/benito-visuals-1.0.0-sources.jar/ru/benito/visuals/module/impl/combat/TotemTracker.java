package ru.benito.visuals.module.impl.combat;

import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

/**
 * TotemTracker — отслеживает использование Totem of Undying другими игроками.
 * Логика "сработал тотем":
 *   1) Игрок держал тотем в off-hand или main-hand в прошлом тике.
 *   2) Сейчас он жив, но у него полное HP, а тотема больше нет.
 * Точное событие сложно перехватить без доп. packet-хуков, поэтому ориентируемся
 * на изменение инвентаря + статус Particle (TotemParticleS2CPacket) не нужен — достаточно стате.
 */
public final class TotemTracker extends Module {

    private final Map<Integer, Boolean> lastHadTotem = new HashMap<>();
    private final Map<Integer, Boolean> lastWasEnchanted = new HashMap<>();

    public TotemTracker() {
        super("TotemTracker", "TotemTracker",
                "Логирование капнувших тотемов", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        lastHadTotem.clear();
        lastWasEnchanted.clear();
    }

    @Override
    public void onTick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;
            int id = p.method_5628();

            class_1799 off = p.method_6079();
            class_1799 main = p.method_6047();
            boolean hasTotem = off.method_31574(class_1802.field_8288) || main.method_31574(class_1802.field_8288);
            boolean enchanted = isEnchanted(off) || isEnchanted(main);

            Boolean had = lastHadTotem.get(id);
            if (had != null && had && !hasTotem && isAlive(p) && isHealed(p)) {
                boolean wasEnch = Boolean.TRUE.equals(lastWasEnchanted.get(id));
                String key = wasEnch ? "benito.msg.totem.enchanted" : "benito.msg.totem.regular";
                mc.field_1705.method_1743().method_1812(class_2561.method_43469(key, p.method_7334().getName()));
            }

            lastHadTotem.put(id, hasTotem);
            if (hasTotem) lastWasEnchanted.put(id, enchanted);
        }
    }

    private boolean isEnchanted(class_1799 stack) {
        if (!stack.method_31574(class_1802.field_8288)) return false;
        class_9304 comp = stack.method_57824(class_9334.field_49633);
        return comp != null && !comp.method_57543();
    }

    private boolean isAlive(class_1309 e) {
        return !e.method_29504() && e.method_6032() > 0f;
    }

    private boolean isHealed(class_1309 e) {
        return e.method_6032() >= 1.0f && e.method_6032() <= e.method_6063();
    }
}
