package ru.benito.visuals.module.impl.combat;

import net.minecraft.class_1297;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import ru.benito.visuals.event.Events;
import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;

/**
 * HitEffect — эффект "волны" при критическом ударе.
 * Используется только при crit == true.
 */
public final class HitEffect extends Module {

    public enum Style { PARTICLES, BLOCKS }

    private Style style = Style.PARTICLES;

    public HitEffect() {
        super("HitEffect", "HitEffect",
                "Эффект волны при критическом ударе", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        Events.ATTACK_ENTITY.register((target, crit) -> {
            if (!isEnabled() || !crit) return;
            spawnWave(target);
        });
    }

    private void spawnWave(class_1297 target) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;
        class_243 origin = target.method_19538();

        int rings = 16;
        double radius = 1.6;
        for (int i = 0; i < rings; i++) {
            double theta = (Math.PI * 2.0) * i / rings;
            double x = origin.field_1352 + Math.cos(theta) * radius;
            double z = origin.field_1350 + Math.sin(theta) * radius;
            double y = origin.field_1351 + 0.05;
            if (style == Style.PARTICLES) {
                mc.field_1687.method_8406(class_2398.field_11205, x, y, z, 0, 0.25, 0);
            } else {
                mc.field_1687.method_8406(class_2398.field_11236, x, y, z, 0, 0, 0);
            }
        }
    }

    public Style getStyle() { return style; }
    public void  setStyle(Style s) { this.style = s; }
}
