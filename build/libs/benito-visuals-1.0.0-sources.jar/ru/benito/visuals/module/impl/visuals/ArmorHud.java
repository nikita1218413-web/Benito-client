package ru.benito.visuals.module.impl.visuals;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import ru.benito.visuals.module.Category;
import ru.benito.visuals.module.Module;
import ru.benito.visuals.render.RenderUtils;

/**
 * ArmorHud — отрисовывает процент прочности экипированной брони
 * над стандартным статус-баром (hotbar). Для 1.21.4 использует DrawContext
 * и API DataComponents (ItemStack#getMaxDamage, #getDamage).
 */
public final class ArmorHud extends Module {

    public ArmorHud() {
        super("ArmorHud", "ArmorHud",
                "Процент прочности брони", Category.VISUALS);
    }

    @Override
    public void onHudRender(class_332 ctx, float tickDelta) {
        class_310 mc = class_310.method_1551();
        class_746 p = mc.field_1724;
        if (p == null) return;

        int sw = ctx.method_51421();
        int sh = ctx.method_51443();

        // Центр над хотбаром
        int baseX = sw / 2 - 91;
        int baseY = sh - 55;

        // 4 слота брони: HEAD, CHEST, LEGS, FEET
        class_1304[] slots = {
                class_1304.field_6169,
                class_1304.field_6174,
                class_1304.field_6172,
                class_1304.field_6166
        };

        for (int i = 0; i < slots.length; i++) {
            class_1799 stack = p.method_6118(slots[i]);
            if (stack.method_7960() || !stack.method_7963()) continue;

            int percent = (int) Math.round(
                    (1.0 - (double) stack.method_7919() / stack.method_7936()) * 100.0);
            percent = Math.max(0, Math.min(100, percent));

            int color = percent > 66 ? 0xFF59E060 : percent > 33 ? 0xFFF0D040 : 0xFFE05060;
            String s = percent + "%";

            int x = baseX + i * 20 + (20 - RenderUtils.textWidth(s)) / 2;
            RenderUtils.text(ctx, s, x, baseY, color, true);
        }
    }
}
