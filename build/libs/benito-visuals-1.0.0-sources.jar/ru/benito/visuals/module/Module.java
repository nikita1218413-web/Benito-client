package ru.benito.visuals.module;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import ru.benito.visuals.BenitoClient;

/**
 * Базовый класс всех модулей.
 * Технические поля — на английском, пользовательские тексты — на русском.
 */
public abstract class Module {

    protected final class_310 mc = class_310.method_1551();

    private final String name;        // Техническое имя (используется для конфига/поиска)
    private final String displayName; // Отображаемое имя (русское)
    private final String description; // Русское описание
    private final Category category;

    private boolean enabled = false;
    private int bind = -1;            // GLFW keycode, -1 = не задан
    private boolean keyHeld = false;

    protected Module(String name, String displayName, String description, Category category) {
        this.name = name;
        this.displayName = displayName;
        this.description = description;
        this.category = category;
    }

    /* ---------- Lifecycle ---------- */

    public final void toggle() { setEnabled(!enabled); }

    public final void setEnabled(boolean value) {
        if (this.enabled == value) return;
        this.enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            // Модуль не должен валить клиент
            BenitoClient.get();
            t.printStackTrace();
        }
        notifyToggle();
    }

    protected void onEnable()  {}
    protected void onDisable() {}

    /** Вызывается каждый клиентский тик, если модуль включён. */
    public void onTick() {}

    /** Вызывается при рендере HUD. */
    public void onHudRender(class_332 ctx, float tickDelta) {}

    /* ---------- Notifications ---------- */

    protected void notifyToggle() {
        if (mc.field_1724 == null) return;
        String key = enabled ? "benito.msg.enabled" : "benito.msg.disabled";
        mc.field_1724.method_7353(class_2561.method_43469(key, displayName), true);
    }

    /* ---------- Getters / Setters ---------- */

    public String   getName()        { return name; }
    public String   getDisplayName() { return displayName; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isEnabled()      { return enabled; }
    public int      getBind()        { return bind; }
    public void     setBind(int key) { this.bind = key; }
    public boolean  isKeyHeld()      { return keyHeld; }
    public void     setKeyHeld(boolean v) { this.keyHeld = v; }
}
