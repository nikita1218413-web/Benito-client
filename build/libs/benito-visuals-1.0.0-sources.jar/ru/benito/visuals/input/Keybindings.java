package ru.benito.visuals.input;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import ru.benito.visuals.BenitoClient;
import ru.benito.visuals.module.Module;
import ru.benito.visuals.module.impl.funtime.CoordInvite;

/**
 * Хоткеи мода. GUI и прочие глобальные бинды.
 */
public final class Keybindings {

    public static final class_304 OPEN_GUI = new class_304(
            "key.benito.gui",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.benito"
    );

    public static final class_304 COORD_INVITE = new class_304(
            "key.benito.coords",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Y,
            "category.benito"
    );

    private Keybindings() {}

    public static void register() {
        KeyBindingHelper.registerKeyBinding(OPEN_GUI);
        KeyBindingHelper.registerKeyBinding(COORD_INVITE);
    }

    /**
     * Обрабатывает динамические бинды модулей (setBind) каждый клиентский тик.
     */
    public static void handle(class_310 mc) {
        if (mc.field_1755 != null) return;

        // Фикс-бинд CoordInvite
        if (COORD_INVITE.method_1436()) {
            Module m = BenitoClient.get().modules().getByName("CoordInvite");
            if (m instanceof CoordInvite ci && m.isEnabled()) {
                ci.sendCoords();
            }
        }

        // Динамические бинды модулей (toggle по нажатию)
        long handle = mc.method_22683().method_4490();
        for (Module module : BenitoClient.get().modules().getModules()) {
            int key = module.getBind();
            if (key <= 0) continue;
            if (GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS) {
                if (!module.isKeyHeld()) {
                    module.toggle();
                    module.setKeyHeld(true);
                }
            } else {
                module.setKeyHeld(false);
            }
        }
    }
}
