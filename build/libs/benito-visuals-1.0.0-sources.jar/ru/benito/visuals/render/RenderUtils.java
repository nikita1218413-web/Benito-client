package ru.benito.visuals.render;

import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Утилиты рендера 2D (GUI / HUD) для Minecraft 1.21.4 на базе DrawContext.
 * 3D-оверлеи в 1.21.4 требуют глубокой интеграции в новую систему рендера,
 * поэтому мировые эффекты (ItemRadius/HitEffect) реализованы через частицы.
 */
public final class RenderUtils {

    private RenderUtils() {}

    public static void fill(class_332 ctx, int x, int y, int w, int h, int argb) {
        ctx.method_25294(x, y, x + w, y + h, argb);
    }

    public static void outline(class_332 ctx, int x, int y, int w, int h, int argb) {
        ctx.method_25294(x,           y,           x + w,     y + 1,     argb);
        ctx.method_25294(x,           y + h - 1,   x + w,     y + h,     argb);
        ctx.method_25294(x,           y + 1,       x + 1,     y + h - 1, argb);
        ctx.method_25294(x + w - 1,   y + 1,       x + w,     y + h - 1, argb);
    }

    public static void rect(class_332 ctx, int x, int y, int w, int h, int fill, int border) {
        fill(ctx, x, y, w, h, fill);
        outline(ctx, x, y, w, h, border);
    }

    public static void roundedRect(class_332 ctx, int x, int y, int w, int h, int radius, int argb) {
        if (radius <= 0) { fill(ctx, x, y, w, h, argb); return; }
        if (radius * 2 > w) radius = w / 2;
        if (radius * 2 > h) radius = h / 2;

        ctx.method_25294(x + radius,     y,              x + w - radius, y + h,          argb);
        ctx.method_25294(x,              y + radius,     x + radius,     y + h - radius, argb);
        ctx.method_25294(x + w - radius, y + radius,     x + w,          y + h - radius, argb);

        for (int i = 0; i < radius; i++) {
            int inset = radius - i;
            ctx.method_25294(x + inset,          y + i,              x + w - inset,          y + i + 1,          argb);
            ctx.method_25294(x + inset,          y + h - i - 1,      x + w - inset,          y + h - i,          argb);
        }
    }

    public static void text(class_332 ctx, String s, int x, int y, int color, boolean shadow) {
        class_310 mc = class_310.method_1551();
        if (shadow) ctx.method_25303(mc.field_1772, s, x, y, color);
        else        ctx.method_51433(mc.field_1772, s, x, y, color, false);
    }

    public static int textWidth(String s) {
        return class_310.method_1551().field_1772.method_1727(s);
    }

    public static int textHeight() {
        return class_310.method_1551().field_1772.field_2000;
    }
}
